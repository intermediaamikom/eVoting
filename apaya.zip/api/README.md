Contoh penggunaan API dengan native PHP
Pada umumnya API adalah komunikasi dua software dengan JSON

-) Akses API yg ada di folder product\... untuk menjalankan API di tabel product
 Akses database dengan hasil JSON: read.php
 Kirim JSON untuk input ke database: create.php
 ... dst bisa dilihat dari judul filenya

-) Contoh kirim JSON dengan PHP: contoh_create.php

-) Uji API juga bisa menggunakan Postman: https://www.postman.com/downloads/

-) Untuk file lain hanya sebagai perangkat penopang contoh API ini

Lebih detail: https://www.codeofaninja.com/2017/02/create-simple-rest-api-in-php.html